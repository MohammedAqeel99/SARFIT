"""
SARFIT - Kivy port of the original Android app.
Developed by Mohammed Aqeel. Ported to Python/Kivy.

Run with:
    pip install -r requirements.txt
    python main.py

Package for Android with buildozer (see buildozer.spec / README.md).
"""

import os

from kivy.config import Config

Config.set("graphics", "width", "390")
Config.set("graphics", "height", "760")

from kivy.app import App
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.uix.screenmanager import NoTransition, ScreenManager

import colors
from screens.day_detail_screen import DayDetailScreen
from screens.login_screen import LoginScreen
from screens.main_screen import MainScreen
from screens.profile_screen import ProfileScreen
from screens.signup_screen import SignupScreen
from screens.split_editor_screen import MusclePickerScreen, SplitEditorScreen
from screens.video_screen import VideoScreen
from screens.warmup_screen import WarmupScreen

# Register the custom font under the name "Roboto" — that's the font family
# Kivy's Label/TapLabel/etc. use by default when no font_name is given, so
# this single registration re-points every existing Label in the app to the
# custom font with no per-screen changes needed.
_FONT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "fonts", "iOS_Semibold.ttf")
if os.path.exists(_FONT_PATH):
    LabelBase.register(name="Roboto", fn_regular=_FONT_PATH)


class SarfitApp(App):
    def build(self):
        self.title = "SARFIT"
        self.username = None
        Window.clearcolor = colors.BG_DARK

        sm = ScreenManager(transition=NoTransition())
        sm.add_widget(LoginScreen(name="login"))
        sm.add_widget(SignupScreen(name="signup"))
        sm.add_widget(MainScreen(name="main"))
        sm.add_widget(DayDetailScreen(name="day_detail"))
        sm.add_widget(WarmupScreen(name="warmup"))
        sm.add_widget(VideoScreen(name="video"))
        sm.add_widget(ProfileScreen(name="profile"))
        sm.add_widget(SplitEditorScreen(name="split_editor"))
        sm.add_widget(MusclePickerScreen(name="muscle_picker"))
        sm.current = "login"
        return sm


if __name__ == "__main__":
    SarfitApp().run()
