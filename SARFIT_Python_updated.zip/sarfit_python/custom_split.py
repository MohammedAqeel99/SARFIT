"""
Lets the user override the default 5-day split by picking any combination
of body parts for any day of the week (e.g. Monday = Chest + Triceps),
instead of being locked to the built-in Chest+Delts / Back+RearDelts /
Arms+Legs+Core grouping.

How it works:
- `MUSCLE_POOL` collects every muscle group's Week 1-4 exercise list from
  the existing hand-written `workout_data.get_schedule()`, keyed by muscle
  name (e.g. "Chest", "Triceps", "Legs"...). This is the pool combinations
  are built from, so exercise data never has to be duplicated.
- The user's chosen combination per day (a list of muscle-group names) is
  stored on-device via `storage.py`.
- `get_effective_schedule()` returns the 7-day week, swapping in a built
  combination for any day the user has customized, and falling back to the
  original default day otherwise.
"""

import storage
from models import MuscleSection, WeekPlan, WorkoutDay
from workout_data import get_schedule

DAY_ORDER = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

# Every body part the user can choose from, in display order.
ALL_MUSCLE_GROUPS = [
    "Chest", "Front Delts", "Side Delts", "Back", "Rear Delts",
    "Biceps", "Triceps", "Legs", "Core", "Cardio",
]


def _build_muscle_pool():
    """muscle_name -> {week_number: [Exercise, ...]}, taken from the first
    day in the default schedule that trains that muscle."""
    pool = {}
    for day in get_schedule():
        for week in day.weeks:
            for section in week.sections:
                by_week = pool.setdefault(section.muscle_name, {})
                by_week.setdefault(week.week_number, section.exercises)
    return pool


MUSCLE_POOL = _build_muscle_pool()


def default_muscles_for(day_name):
    """The stock (non-custom) muscle groups trained on a given day, used to
    pre-select chips when the user opens the picker for the first time."""
    for day in get_schedule():
        if day.day_name == day_name and not day.is_rest:
            # dedupe while keeping order across the 4 weeks
            seen = []
            for week in day.weeks:
                for section in week.sections:
                    if section.muscle_name not in seen:
                        seen.append(section.muscle_name)
            return seen
    return []


def build_custom_day(day_name, muscle_names):
    """Build a WorkoutDay by combining the chosen muscle groups' pools."""
    muscle_names = [m for m in muscle_names if m in MUSCLE_POOL]
    if not muscle_names:
        return None

    weeks = []
    for week_num in (1, 2, 3, 4):
        sections = [
            MuscleSection(m, MUSCLE_POOL[m].get(week_num, []))
            for m in muscle_names
        ]
        weeks.append(WeekPlan(week_num, sections))

    focus = " + ".join(muscle_names)
    return WorkoutDay(day_name, focus, False, weeks, "custom")


def get_effective_schedule():
    """The 7-day week the app should display: default days, with any
    user-customized days swapped in."""
    base_by_name = {d.day_name: d for d in get_schedule()}
    overrides = storage.get_custom_split()

    result = []
    for name in DAY_ORDER:
        chosen = overrides.get(name)
        if chosen:
            custom_day = build_custom_day(name, chosen)
            result.append(custom_day or base_by_name[name])
        else:
            result.append(base_by_name[name])
    return result
