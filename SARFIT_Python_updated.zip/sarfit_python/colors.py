"""
Theme colors, port of res/values/colors.xml.
Kivy colors are RGBA tuples in the 0-1 range.
"""


def hex_to_rgba(hex_color, alpha=1.0):
    hex_color = hex_color.lstrip("#")
    r = int(hex_color[0:2], 16) / 255.0
    g = int(hex_color[2:4], 16) / 255.0
    b = int(hex_color[4:6], 16) / 255.0
    return (r, g, b, alpha)


BG_DARK = hex_to_rgba("#0A0A0A")
BG_SURFACE = hex_to_rgba("#1A1A1E")
BG_CARD = hex_to_rgba("#151518")
NEON_GREEN = hex_to_rgba("#39FF14")
NEON_CYAN = hex_to_rgba("#00F0FF")
NEON_PINK = hex_to_rgba("#FF2E9F")
NEON_GOLD = hex_to_rgba("#FFD700")
TEXT_PRIMARY = hex_to_rgba("#FFFFFF")
TEXT_SECONDARY = hex_to_rgba("#9E9E9E")
REST_GREY = hex_to_rgba("#3A3A3A")
ERROR_RED = hex_to_rgba("#FF4C4C")

SKIN_BASE = hex_to_rgba("#3A3A42")
SKIN_LIGHT = hex_to_rgba("#55555E")


def accent_for(group):
    """Port of accentFor() used in MainActivity / DayDetailActivity."""
    return {
        "chest_delts": NEON_GREEN,
        "back_rear_delts": NEON_CYAN,
        "arms_legs_core": NEON_PINK,
        "cardio": NEON_GOLD,
    }.get(group, hex_to_rgba("#888888"))


def accent_for_day(day):
    """Like accent_for(), but for a user-built custom combo day (body_highlight
    == "custom"), pick the color of the first chosen muscle group instead of
    the generic grey fallback."""
    if day.body_highlight != "custom":
        return accent_for(day.body_highlight)

    from body_model import BodyModel  # local import: avoids a circular import

    if day.weeks and day.weeks[0].sections:
        first_muscle = day.weeks[0].sections[0].muscle_name
        entry = BodyModel.MUSCLE_MAP.get(first_muscle)
        if entry:
            return globals()[entry[2]]
    return accent_for(day.body_highlight)
