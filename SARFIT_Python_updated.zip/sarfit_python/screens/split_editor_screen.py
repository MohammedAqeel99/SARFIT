"""
Lets the user build their own split: pick any combination of body parts to
train on each day of the week (e.g. Monday = Chest + Triceps, Tuesday =
Back alone, etc.), instead of the app's fixed default grouping.

Two screens:
- SplitEditorScreen: the 7-day list, showing what's currently trained (or
  customized) each day. Tap a day to edit it.
- MusclePickerScreen: a chip grid of every body part for one day, toggle
  any combination on/off, then Save (or Reset to Default).
"""

from kivy.graphics import Color, RoundedRectangle
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import Screen

import colors
import storage
from custom_split import ALL_MUSCLE_GROUPS, DAY_ORDER, default_muscles_for
from ui_common import BackgroundBox, TapCard, TapLabel


class SplitEditorScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._build()

    def _build(self):
        root = BackgroundBox(orientation="vertical", padding=16, spacing=8)

        header_row = BoxLayout(size_hint=(1, None), height=32)
        back_btn = TapLabel(text="\u2190 Back", color=colors.TEXT_SECONDARY, size_hint=(None, 1), width=70)
        back_btn.bind(on_release=lambda *_: setattr(self.manager, "current", "main"))
        header_row.add_widget(back_btn)
        root.add_widget(header_row)

        title = Label(text="Customize Split", font_size=22, bold=True, color=colors.TEXT_PRIMARY,
                       size_hint=(1, None), height=32, halign="left")
        title.bind(size=lambda w, *_: setattr(w, "text_size", w.size))
        root.add_widget(title)

        subtitle = Label(
            text="Tap a day to choose any combination of body parts to train.",
            font_size=13, color=colors.TEXT_SECONDARY, size_hint=(1, None), height=36,
            halign="left", valign="top",
        )
        subtitle.bind(size=lambda w, *_: setattr(w, "text_size", w.size))
        root.add_widget(subtitle)

        scroll = ScrollView(size_hint=(1, 1))
        self.day_list = BoxLayout(orientation="vertical", spacing=10, size_hint_y=None, padding=[0, 6, 0, 6])
        self.day_list.bind(minimum_height=self.day_list.setter("height"))
        scroll.add_widget(self.day_list)
        root.add_widget(scroll)

        reset_btn = TapLabel(
            text="Reset all days to default  \u21bb", color=colors.ERROR_RED, font_size=13,
            size_hint=(1, None), height=30,
        )
        reset_btn.bind(on_release=self._reset_all)
        root.add_widget(reset_btn)

        self.add_widget(root)

    def on_pre_enter(self, *args):
        self._refresh()

    def _refresh(self):
        self.day_list.clear_widgets()
        overrides = storage.get_custom_split()
        for day_name in DAY_ORDER:
            self.day_list.add_widget(self._build_day_row(day_name, overrides.get(day_name)))

    def _build_day_row(self, day_name, custom_muscles):
        card = TapCard(orientation="vertical", padding=14, spacing=2, size_hint=(1, None), height=68)
        card.add_widget(Label(
            text=day_name, font_size=17, bold=True, color=colors.TEXT_PRIMARY,
            halign="left", size_hint=(1, None), height=22,
        ))

        if custom_muscles:
            summary = "Custom: " + " + ".join(custom_muscles)
            summary_color = colors.NEON_PINK
        else:
            defaults = default_muscles_for(day_name)
            summary = ("Default: " + " + ".join(defaults)) if defaults else "Rest day"
            summary_color = colors.TEXT_SECONDARY

        card.add_widget(Label(
            text=summary, font_size=12, color=summary_color,
            halign="left", size_hint=(1, None), height=18,
        ))
        for child in card.children:
            child.bind(size=lambda w, *_: setattr(w, "text_size", w.size))

        card.bind(on_release=lambda *_a, d=day_name: self._open_picker(d))
        return card

    def _open_picker(self, day_name):
        picker = self.manager.get_screen("muscle_picker")
        picker.load_day(day_name)
        self.manager.current = "muscle_picker"

    def _reset_all(self, *args):
        storage.reset_custom_split()
        self._refresh()


class MusclePickerScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.day_name = None
        self.selected = set()
        self.chips = {}
        self._build()

    def _build(self):
        root = BackgroundBox(orientation="vertical", padding=16, spacing=8)

        header_row = BoxLayout(size_hint=(1, None), height=32)
        back_btn = TapLabel(text="\u2190 Back", color=colors.TEXT_SECONDARY, size_hint=(None, 1), width=70)
        back_btn.bind(on_release=lambda *_: setattr(self.manager, "current", "split_editor"))
        header_row.add_widget(back_btn)
        root.add_widget(header_row)

        self.title_label = Label(text="", font_size=22, bold=True, color=colors.TEXT_PRIMARY,
                                  size_hint=(1, None), height=32, halign="left")
        self.title_label.bind(size=lambda w, *_: setattr(w, "text_size", w.size))
        root.add_widget(self.title_label)

        subtitle = Label(
            text="Tap to select any combination \u2014 alone or combined.",
            font_size=13, color=colors.TEXT_SECONDARY, size_hint=(1, None), height=24,
            halign="left",
        )
        subtitle.bind(size=lambda w, *_: setattr(w, "text_size", w.size))
        root.add_widget(subtitle)

        scroll = ScrollView(size_hint=(1, 1))
        self.grid = GridLayout(cols=2, spacing=10, size_hint_y=None, padding=[0, 8, 0, 8])
        self.grid.bind(minimum_height=self.grid.setter("height"))
        scroll.add_widget(self.grid)
        root.add_widget(scroll)

        button_row = BoxLayout(size_hint=(1, None), height=48, spacing=10)
        reset_btn = TapCard(orientation="vertical", size_hint=(1, 1))
        reset_btn.add_widget(Label(text="Reset to Default", color=colors.TEXT_SECONDARY, bold=True))
        reset_btn.bind(on_release=self._reset_day)
        button_row.add_widget(reset_btn)

        self.save_btn = TapCard(orientation="vertical", size_hint=(1, 1))
        self.save_btn.add_widget(Label(text="Save", color=colors.NEON_GREEN, bold=True))
        self.save_btn.bind(on_release=self._save)
        button_row.add_widget(self.save_btn)
        root.add_widget(button_row)

        self.add_widget(root)

    def load_day(self, day_name):
        self.day_name = day_name
        self.title_label.text = day_name
        overrides = storage.get_custom_split()
        current = overrides.get(day_name) or default_muscles_for(day_name)
        self.selected = set(current)

        self.grid.clear_widgets()
        self.chips = {}
        for muscle in ALL_MUSCLE_GROUPS:
            chip = self._build_chip(muscle)
            self.chips[muscle] = chip
            self.grid.add_widget(chip)

    def _build_chip(self, muscle_name):
        chip = TapCard(orientation="vertical", size_hint=(1, None), height=48)
        label = Label(text=muscle_name, bold=True, color=colors.TEXT_PRIMARY)
        chip.add_widget(label)

        # Draw one persistent rounded-rect on top of Card's own background;
        # later taps just update this Color's rgba instead of touching the
        # canvas or rebinding callbacks each time.
        with chip.canvas.before:
            color_instr = Color(*colors.BG_CARD)
            rect = RoundedRectangle(size=chip.size, pos=chip.pos, radius=[10])
        chip.bind(size=lambda w, *_a, r=rect: (setattr(r, "size", w.size), setattr(r, "pos", w.pos)))
        chip.bind(pos=lambda w, *_a, r=rect: setattr(r, "pos", w.pos))
        chip._bg_color_instr = color_instr
        chip._label = label

        chip.bind(on_release=lambda *_a, m=muscle_name: self._toggle(m))
        self._paint_chip(chip, muscle_name in self.selected)
        return chip

    def _paint_chip(self, chip, selected):
        chip._bg_color_instr.rgba = colors.NEON_PINK if selected else colors.BG_CARD
        chip._label.color = (0, 0, 0, 1) if selected else colors.TEXT_PRIMARY

    def _toggle(self, muscle_name):
        if muscle_name in self.selected:
            self.selected.discard(muscle_name)
        else:
            self.selected.add(muscle_name)
        self._paint_chip(self.chips[muscle_name], muscle_name in self.selected)

    def _save(self, *args):
        storage.save_custom_split_for_day(self.day_name, sorted(
            self.selected, key=ALL_MUSCLE_GROUPS.index
        ))
        self.manager.current = "split_editor"

    def _reset_day(self, *args):
        storage.save_custom_split_for_day(self.day_name, [])
        self.manager.current = "split_editor"
